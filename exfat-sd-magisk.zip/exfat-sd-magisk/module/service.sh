#!/system/bin/sh
# Jalan saat boot. Memantau kartu: mount otomatis saat dipasang, bersihkan saat dicabut.
MODDIR=${0%/*}
CONF=/data/adb/universal_sd/config
FAILED=/data/local/tmp/universal_sd.failed

AUTO_MOUNT=1
[ -f "$CONF" ] && . "$CONF"

(
  while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
  sleep 10
  rm -f "$FAILED"

  while true; do
    [ -f "$CONF" ] && . "$CONF"
    if [ "$AUTO_MOUNT" = "1" ]; then
      sh "$MODDIR/system/bin/sd-umount" --stale >/dev/null 2>&1
      list=$(sh "$MODDIR/system/bin/sd-mount" --list)
      if [ -n "$list" ]; then
        sh "$MODDIR/system/bin/sd-mount" --auto >/dev/null 2>&1
      else
        rm -f "$FAILED"   # kartu dicabut: coba lagi saat dipasang lagi
      fi
    fi
    sleep 5
  done
) &
