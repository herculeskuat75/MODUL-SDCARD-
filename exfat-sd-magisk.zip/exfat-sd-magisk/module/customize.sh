#!/system/bin/sh
# Installer Magisk (v24+). Variabel $MODPATH, $ARCH, ui_print, abort disediakan Magisk.
SKIPUNZIP=0

ui_print "- Universal SD Card Support"

if [ "$ARCH" != "arm64" ]; then
  abort "! Hanya arm64 yang didukung (perangkat ini: $ARCH)"
fi

[ -f "$MODPATH/bin/mount.exfat-fuse" ] || ui_print "! mount.exfat-fuse tidak ada: exFAT hanya jalan jika kernel punya driver exfat/sdfat."
[ -f "$MODPATH/bin/ntfs-3g" ] || ui_print "! ntfs-3g tidak ada: NTFS hanya baca (driver kernel) jika tersedia."

CONF_DIR=/data/adb/universal_sd
mkdir -p "$CONF_DIR"
if [ ! -f "$CONF_DIR/config" ]; then
  cat > "$CONF_DIR/config" <<'EOF'
# Konfigurasi Universal SD Card Support
AUTO_MOUNT=1      # 1 = mount otomatis saat kartu terdeteksi
READ_ONLY=0       # 1 = mount read-only (lebih aman)
BIND_SDCARD=1     # 1 = tampilkan di /sdcard/SD-<nama> agar terlihat file manager biasa
HANDLE_VFAT=0     # 1 = modul juga mount FAT32 (biasanya sudah ditangani Android)
# DEVICES="/dev/block/mmcblk1p1"   # isi jika kartu tidak terdeteksi otomatis
EOF
  ui_print "- Config dibuat: $CONF_DIR/config"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
[ -d "$MODPATH/bin" ] && set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
for f in sd-mount sd-umount sd-info; do
  set_perm "$MODPATH/system/bin/$f" 0 2000 0755
done

ui_print "- Selesai. Reboot, lalu pasang kartu apa pun."
ui_print "- Data kartu tidak diformat atau diubah."
