#!/system/bin/sh
sh /data/adb/modules/universal_sd_support/system/bin/sd-umount >/dev/null 2>&1
rmdir /data/media/0/SD-* 2>/dev/null
rm -rf /data/adb/universal_sd /data/local/tmp/universal_sd.failed
