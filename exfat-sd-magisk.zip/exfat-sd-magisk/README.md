# Universal SD Card Support (modul Magisk)

Membuat HP root (mis. Redmi Note 5 / whyred, Arrow OS 12.1, kernel 4.4) membaca dan menulis
kartu SD / flashdisk OTG **format apa pun tanpa format ulang**.

| Format | Driver |
|---|---|
| exFAT | kernel (`exfat`/`sdfat`) jika ada, otherwise FUSE `mount.exfat-fuse` |
| NTFS | FUSE `ntfs-3g` (baca/tulis); fallback kernel `ntfs` (baca saja) |
| FAT16/FAT32 | bawaan Android (modul tidak ikut campur, `HANDLE_VFAT=1` untuk ambil alih) |
| ext2/3/4, F2FS, Btrfs, XFS | driver kernel, jika kernel mendukung |

Format dikenali dari tanda tangan di partisi, bukan dari ekstensi atau nama. Data tidak diubah.

## Build lewat GitHub Actions
1. Buat repo GitHub baru, upload seluruh isi folder ini.
2. Actions → **Build modul Magisk Universal SD** → Run workflow.
3. Unduh artifact `universal-sd-support-magisk` (zip modul).
4. Magisk → Modules → Install from storage → pilih zip → reboot.

Rilis otomatis: `git tag v2.0.0 && git push --tags`.

## Pemakaian
- Mount otomatis saat boot dan saat kartu dipasang, ke `/mnt/sdx/<partisi>`.
- Dengan `BIND_SDCARD=1` (default) juga tampil di `/sdcard/SD-<partisi>` untuk file manager biasa.
- `su -c sd-mount` mount manual, `su -c sd-info` diagnosa.
- **Lepas sebelum mencabut kartu:** `su -c sd-umount`.
- Config: `/data/adb/universal_sd/config`. Log: `/data/local/tmp/universal_sd.log`.

## Batasan
- Hanya arm64. Belum diuji di perangkat. Build FUSE memakai libfuse patch Android; bila gagal, lihat log Actions.
- NTFS bersifat opsional di build: jika `ntfs-3g` gagal dibuild, exFAT tetap ikut.
- ext4/F2FS/Btrfs/XFS butuh dukungan kernel (`grep -E 'ext4|f2fs' /proc/filesystems`); FUSE tidak dipakai untuk itu.
  Pada ext4/F2FS izin file tetap milik Linux, jadi file bisa tidak bisa ditulis aplikasi biasa.
- Aplikasi biasa tidak selalu melihat bind-mount di `/sdcard`, tergantung ROM.
